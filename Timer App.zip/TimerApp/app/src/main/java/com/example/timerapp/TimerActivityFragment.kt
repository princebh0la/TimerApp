package com.example.timerapp

class TimerActivityFragment : PrefernceFragmentCompat() {
}